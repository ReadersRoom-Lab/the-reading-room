document.addEventListener('DOMContentLoaded', () => {
  const saveBtn = document.getElementById('save-btn');
  const statusEl = document.getElementById('status-container');
  const BACKEND_URL = 'http://localhost:3000';

  saveBtn.addEventListener('click', async () => {
    saveBtn.disabled = true;
    saveBtn.innerHTML = 'Saving...';
    statusEl.className = 'status hidden';
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab.url || tab.url.startsWith('chrome://')) throw new Error('Cannot save this type of page.');
      const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => document.documentElement.outerHTML });
      const html = results[0].result;
      const response = await fetch(BACKEND_URL + '/api/articles/extension', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ url: tab.url, html, roomId: null })
      });
      const data = await response.json().catch(() => ({ error: 'Invalid response' }));
      if (!response.ok) throw new Error(data.error || 'Failed to save article.');
      statusEl.textContent = 'Saved to The Reading Room!';
      statusEl.className = 'status success';
      saveBtn.innerHTML = 'Saved ✓';
      setTimeout(() => window.close(), 2000);
    } catch (err) {
      let msg = err.message || 'An unexpected error occurred.';
      if (msg === 'Failed to fetch') msg = 'Could not connect. Make sure you are logged in to The Reading Room.';
      statusEl.textContent = msg;
      statusEl.className = 'status error';
      saveBtn.disabled = false;
      saveBtn.innerHTML = 'Try Again';
    }
  });
});